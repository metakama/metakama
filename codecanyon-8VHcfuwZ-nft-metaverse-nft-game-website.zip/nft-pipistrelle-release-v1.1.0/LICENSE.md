SEE LICENSE IN: https://codecanyon.net/licenses/standard

FULL TEXT OF REGULAR LICENSE: https://codecanyon.net/licenses/terms/regular

FULL TEXT OF EXTENDED LICENSE: https://codecanyon.net/licenses/terms/extended